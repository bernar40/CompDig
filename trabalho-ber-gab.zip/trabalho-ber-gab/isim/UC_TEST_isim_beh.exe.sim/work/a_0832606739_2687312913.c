/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/aula.ELE.000/Downloads/CompDig-master (1)/CompDig-master/alu.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3499444699;

char *ieee_p_2592010699_sub_1697423399_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);
char *ieee_p_2592010699_sub_3798478767_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_3499444699_sub_1770399666_3536714472(char *, char *, char *, int );
char *ieee_p_3499444699_sub_278355757_3536714472(char *, char *, char *, char *, char *, char *);
char *ieee_p_3499444699_sub_278427631_3536714472(char *, char *, char *, char *, char *, char *);
char *ieee_p_3499444699_sub_4198114602_3536714472(char *, char *, char *, char *, int );
char *ieee_p_3499444699_sub_4198186476_3536714472(char *, char *, char *, char *, int );


static void work_a_0832606739_2687312913_p_0(char *t0)
{
    char t39[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    int t16;
    int t17;
    char *t18;
    char *t19;
    int t20;
    char *t21;
    int t23;
    char *t24;
    int t26;
    char *t27;
    int t29;
    char *t30;
    int t32;
    char *t33;
    int t35;
    char *t36;
    int t38;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    static char *nl0[] = {&&LAB6, &&LAB7, &&LAB8, &&LAB9};

LAB0:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4112);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(59, ng0);
    t3 = (t0 + 2472U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t3 = (char *)((nl0) + t5);
    goto **((char **)t3);

LAB5:    goto LAB3;

LAB6:    xsi_set_current_line(61, ng0);
    t6 = (t0 + 1672U);
    t7 = *((char **)t6);
    t8 = *((unsigned char *)t7);
    t9 = (t8 == (unsigned char)3);
    if (t9 != 0)
        goto LAB11;

LAB13:
LAB12:    goto LAB5;

LAB7:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t1 = (t0 + 7281);
    t14 = xsi_mem_cmp(t1, t3, 5U);
    if (t14 == 1)
        goto LAB15;

LAB27:    t6 = (t0 + 7286);
    t15 = xsi_mem_cmp(t6, t3, 5U);
    if (t15 == 1)
        goto LAB16;

LAB28:    t10 = (t0 + 7291);
    t16 = xsi_mem_cmp(t10, t3, 5U);
    if (t16 == 1)
        goto LAB17;

LAB29:    t12 = (t0 + 7296);
    t17 = xsi_mem_cmp(t12, t3, 5U);
    if (t17 == 1)
        goto LAB18;

LAB30:    t18 = (t0 + 7301);
    t20 = xsi_mem_cmp(t18, t3, 5U);
    if (t20 == 1)
        goto LAB19;

LAB31:    t21 = (t0 + 7306);
    t23 = xsi_mem_cmp(t21, t3, 5U);
    if (t23 == 1)
        goto LAB20;

LAB32:    t24 = (t0 + 7311);
    t26 = xsi_mem_cmp(t24, t3, 5U);
    if (t26 == 1)
        goto LAB21;

LAB33:    t27 = (t0 + 7316);
    t29 = xsi_mem_cmp(t27, t3, 5U);
    if (t29 == 1)
        goto LAB22;

LAB34:    t30 = (t0 + 7321);
    t32 = xsi_mem_cmp(t30, t3, 5U);
    if (t32 == 1)
        goto LAB23;

LAB35:    t33 = (t0 + 7326);
    t35 = xsi_mem_cmp(t33, t3, 5U);
    if (t35 == 1)
        goto LAB24;

LAB36:    t36 = (t0 + 7331);
    t38 = xsi_mem_cmp(t36, t3, 5U);
    if (t38 == 1)
        goto LAB25;

LAB37:
LAB26:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 7336);
    t4 = (t0 + 4320);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 5U);
    xsi_driver_first_trans_fast(t4);

LAB14:    xsi_set_current_line(91, ng0);
    t1 = (t0 + 4192);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB8:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 2632U);
    t3 = *((char **)t1);
    t1 = (t0 + 4384);
    t4 = (t1 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    memcpy(t10, t3, 5U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(95, ng0);
    t1 = (t0 + 4448);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(96, ng0);
    t1 = (t0 + 4192);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(97, ng0);
    t1 = (t0 + 2632U);
    t3 = *((char **)t1);
    t14 = (4 - 4);
    t46 = (t14 * -1);
    t47 = (1U * t46);
    t53 = (0 + t47);
    t1 = (t3 + t53);
    t2 = *((unsigned char *)t1);
    t4 = (t0 + 4256);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t2;
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(98, ng0);
    t1 = (t0 + 2632U);
    t3 = *((char **)t1);
    t1 = (t0 + 7232U);
    t2 = ieee_p_3499444699_sub_1770399666_3536714472(IEEE_P_3499444699, t3, t1, 0);
    if (t2 != 0)
        goto LAB61;

LAB63:    xsi_set_current_line(101, ng0);
    t1 = (t0 + 4512);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB62:    goto LAB5;

LAB9:    xsi_set_current_line(105, ng0);
    t1 = (t0 + 4448);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(106, ng0);
    t1 = (t0 + 4192);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB10:    xsi_set_current_line(109, ng0);
    t1 = (t0 + 4192);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB11:    xsi_set_current_line(62, ng0);
    t6 = (t0 + 4192);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)1;
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 4256);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB12;

LAB15:    xsi_set_current_line(67, ng0);
    t40 = (t0 + 1192U);
    t41 = *((char **)t40);
    t40 = (t0 + 7168U);
    t42 = (t0 + 1352U);
    t43 = *((char **)t42);
    t42 = (t0 + 7184U);
    t44 = ieee_p_3499444699_sub_278355757_3536714472(IEEE_P_3499444699, t39, t41, t40, t43, t42);
    t45 = (t39 + 12U);
    t46 = *((unsigned int *)t45);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB39;

LAB40:    t48 = (t0 + 4320);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    memcpy(t52, t44, 5U);
    xsi_driver_first_trans_fast(t48);
    goto LAB14;

LAB16:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    t4 = (t0 + 7184U);
    t7 = ieee_p_3499444699_sub_278427631_3536714472(IEEE_P_3499444699, t39, t3, t1, t6, t4);
    t10 = (t39 + 12U);
    t46 = *((unsigned int *)t10);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB41;

LAB42:    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t18 = (t13 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t7, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB14;

LAB17:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    t4 = (t0 + 7184U);
    t7 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t39, t3, t1, t6, t4);
    t10 = (t39 + 12U);
    t46 = *((unsigned int *)t10);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB43;

LAB44:    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t18 = (t13 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t7, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB14;

LAB18:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    t4 = (t0 + 7184U);
    t7 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t39, t3, t1, t6, t4);
    t10 = (t39 + 12U);
    t46 = *((unsigned int *)t10);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB45;

LAB46:    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t18 = (t13 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t7, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB14;

LAB19:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    t4 = (t0 + 7184U);
    t7 = ieee_p_2592010699_sub_1697423399_503743352(IEEE_P_2592010699, t39, t3, t1, t6, t4);
    t10 = (t39 + 12U);
    t46 = *((unsigned int *)t10);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB47;

LAB48:    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t18 = (t13 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t7, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB14;

LAB20:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t39, t3, t1);
    t6 = (t39 + 12U);
    t46 = *((unsigned int *)t6);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB49;

LAB50:    t7 = (t0 + 4320);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 5U);
    xsi_driver_first_trans_fast(t7);
    goto LAB14;

LAB21:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    t4 = (t0 + 7184U);
    t7 = ieee_p_2592010699_sub_3798478767_503743352(IEEE_P_2592010699, t39, t3, t1, t6, t4);
    t10 = (t39 + 12U);
    t46 = *((unsigned int *)t10);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB51;

LAB52:    t11 = (t0 + 4320);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t18 = (t13 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t7, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB14;

LAB22:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = ieee_p_3499444699_sub_4198114602_3536714472(IEEE_P_3499444699, t39, t3, t1, 1);
    t6 = (t39 + 12U);
    t46 = *((unsigned int *)t6);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB53;

LAB54:    t7 = (t0 + 4320);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 5U);
    xsi_driver_first_trans_fast(t7);
    goto LAB14;

LAB23:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t1 = (t0 + 7184U);
    t4 = ieee_p_3499444699_sub_4198114602_3536714472(IEEE_P_3499444699, t39, t3, t1, 1);
    t6 = (t39 + 12U);
    t46 = *((unsigned int *)t6);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB55;

LAB56:    t7 = (t0 + 4320);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 5U);
    xsi_driver_first_trans_fast(t7);
    goto LAB14;

LAB24:    xsi_set_current_line(85, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 7168U);
    t4 = ieee_p_3499444699_sub_4198186476_3536714472(IEEE_P_3499444699, t39, t3, t1, 1);
    t6 = (t39 + 12U);
    t46 = *((unsigned int *)t6);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB57;

LAB58:    t7 = (t0 + 4320);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 5U);
    xsi_driver_first_trans_fast(t7);
    goto LAB14;

LAB25:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t1 = (t0 + 7184U);
    t4 = ieee_p_3499444699_sub_4198186476_3536714472(IEEE_P_3499444699, t39, t3, t1, 1);
    t6 = (t39 + 12U);
    t46 = *((unsigned int *)t6);
    t47 = (1U * t46);
    t2 = (5U != t47);
    if (t2 == 1)
        goto LAB59;

LAB60:    t7 = (t0 + 4320);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 5U);
    xsi_driver_first_trans_fast(t7);
    goto LAB14;

LAB38:;
LAB39:    xsi_size_not_matching(5U, t47, 0);
    goto LAB40;

LAB41:    xsi_size_not_matching(5U, t47, 0);
    goto LAB42;

LAB43:    xsi_size_not_matching(5U, t47, 0);
    goto LAB44;

LAB45:    xsi_size_not_matching(5U, t47, 0);
    goto LAB46;

LAB47:    xsi_size_not_matching(5U, t47, 0);
    goto LAB48;

LAB49:    xsi_size_not_matching(5U, t47, 0);
    goto LAB50;

LAB51:    xsi_size_not_matching(5U, t47, 0);
    goto LAB52;

LAB53:    xsi_size_not_matching(5U, t47, 0);
    goto LAB54;

LAB55:    xsi_size_not_matching(5U, t47, 0);
    goto LAB56;

LAB57:    xsi_size_not_matching(5U, t47, 0);
    goto LAB58;

LAB59:    xsi_size_not_matching(5U, t47, 0);
    goto LAB60;

LAB61:    xsi_set_current_line(99, ng0);
    t4 = (t0 + 4512);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

}


extern void work_a_0832606739_2687312913_init()
{
	static char *pe[] = {(void *)work_a_0832606739_2687312913_p_0};
	xsi_register_didat("work_a_0832606739_2687312913", "isim/UC_TEST_isim_beh.exe.sim/work/a_0832606739_2687312913.didat");
	xsi_register_executes(pe);
}
