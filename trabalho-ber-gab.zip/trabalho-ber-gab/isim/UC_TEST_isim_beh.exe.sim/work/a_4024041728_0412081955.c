/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/aula.ELE.000/Downloads/CompDig-master (1)/CompDig-master/memoria_ram.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_4024041728_0412081955_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(35, ng0);

LAB3:    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t3 = (4 - 4);
    t4 = (t3 * 1U);
    t5 = (30 - 0);
    t6 = (t5 * 1);
    t7 = (5U * t6);
    t8 = (0 + t7);
    t9 = (t8 + t4);
    t1 = (t2 + t9);
    t10 = (t0 + 4520);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 5U);
    xsi_driver_first_trans_fast_port(t10);

LAB2:    t15 = (t0 + 4408);
    *((int *)t15) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_4024041728_0412081955_p_1(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    int t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    char *t38;
    int t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;
    char *t44;
    int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    char *t50;
    int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    char *t56;
    int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    char *t68;
    int t70;
    unsigned int t71;
    unsigned int t72;
    char *t73;
    char *t74;
    int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    char *t80;
    int t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;
    char *t86;
    int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    char *t92;
    int t94;
    unsigned int t95;
    unsigned int t96;
    char *t97;
    char *t98;
    int t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    char *t104;
    int t106;
    unsigned int t107;
    unsigned int t108;
    char *t109;
    char *t110;
    int t112;
    unsigned int t113;
    unsigned int t114;
    char *t115;
    char *t116;
    int t118;
    unsigned int t119;
    unsigned int t120;
    char *t121;
    char *t122;
    int t124;
    unsigned int t125;
    unsigned int t126;
    char *t127;
    char *t128;
    int t130;
    unsigned int t131;
    unsigned int t132;
    char *t133;
    char *t134;
    int t136;
    unsigned int t137;
    unsigned int t138;
    char *t139;
    char *t140;
    int t142;
    unsigned int t143;
    unsigned int t144;
    char *t145;
    char *t146;
    int t148;
    unsigned int t149;
    unsigned int t150;
    char *t151;
    char *t152;
    int t154;
    unsigned int t155;
    unsigned int t156;
    char *t157;
    char *t158;
    int t160;
    unsigned int t161;
    unsigned int t162;
    char *t163;
    char *t164;
    int t166;
    unsigned int t167;
    unsigned int t168;
    char *t169;
    char *t170;
    int t172;
    unsigned int t173;
    unsigned int t174;
    char *t175;
    char *t176;
    int t178;
    unsigned int t179;
    unsigned int t180;
    char *t181;
    char *t182;
    int t184;
    unsigned int t185;
    unsigned int t186;
    char *t187;
    char *t188;
    int t190;
    unsigned int t191;
    unsigned int t192;
    char *t193;
    char *t194;
    int t196;
    unsigned int t197;
    unsigned int t198;
    char *t199;
    char *t200;
    char *t201;
    char *t202;
    char *t203;
    char *t204;

LAB0:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4424);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(40, ng0);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t5 = (t2 == (unsigned char)3);
    if (t5 != 0)
        goto LAB8;

LAB9:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 1832U);
    t3 = *((char **)t1);
    t1 = (t0 + 1512U);
    t4 = *((char **)t1);
    t10 = *((int *)t4);
    t16 = (t10 - 0);
    t11 = (t16 * 1);
    t12 = (5U * t11);
    t17 = (0U + t12);
    t1 = (t0 + 4584);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t13 = *((char **)t9);
    memcpy(t13, t3, 5U);
    xsi_driver_first_trans_delta(t1, t17, 5U, 0LL);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(41, ng0);
    t3 = xsi_get_transient_memory(160U);
    memset(t3, 0, 160U);
    t7 = t3;
    t8 = (t0 + 8081);
    t10 = (0 - 0);
    t11 = (t10 * 1);
    t12 = (5U * t11);
    t13 = (t7 + t12);
    memcpy(t13, t8, 5U);
    t14 = (t0 + 8086);
    t16 = (1 - 0);
    t17 = (t16 * 1);
    t18 = (5U * t17);
    t19 = (t7 + t18);
    memcpy(t19, t14, 5U);
    t20 = (t0 + 8091);
    t22 = (2 - 0);
    t23 = (t22 * 1);
    t24 = (5U * t23);
    t25 = (t7 + t24);
    memcpy(t25, t20, 5U);
    t26 = (t0 + 8096);
    t28 = (3 - 0);
    t29 = (t28 * 1);
    t30 = (5U * t29);
    t31 = (t7 + t30);
    memcpy(t31, t26, 5U);
    t32 = (t0 + 8101);
    t34 = (4 - 0);
    t35 = (t34 * 1);
    t36 = (5U * t35);
    t37 = (t7 + t36);
    memcpy(t37, t32, 5U);
    t38 = (t0 + 8106);
    t40 = (5 - 0);
    t41 = (t40 * 1);
    t42 = (5U * t41);
    t43 = (t7 + t42);
    memcpy(t43, t38, 5U);
    t44 = (t0 + 8111);
    t46 = (6 - 0);
    t47 = (t46 * 1);
    t48 = (5U * t47);
    t49 = (t7 + t48);
    memcpy(t49, t44, 5U);
    t50 = (t0 + 8116);
    t52 = (7 - 0);
    t53 = (t52 * 1);
    t54 = (5U * t53);
    t55 = (t7 + t54);
    memcpy(t55, t50, 5U);
    t56 = (t0 + 8121);
    t58 = (8 - 0);
    t59 = (t58 * 1);
    t60 = (5U * t59);
    t61 = (t7 + t60);
    memcpy(t61, t56, 5U);
    t62 = (t0 + 8126);
    t64 = (9 - 0);
    t65 = (t64 * 1);
    t66 = (5U * t65);
    t67 = (t7 + t66);
    memcpy(t67, t62, 5U);
    t68 = (t0 + 8131);
    t70 = (10 - 0);
    t71 = (t70 * 1);
    t72 = (5U * t71);
    t73 = (t7 + t72);
    memcpy(t73, t68, 5U);
    t74 = (t0 + 8136);
    t76 = (11 - 0);
    t77 = (t76 * 1);
    t78 = (5U * t77);
    t79 = (t7 + t78);
    memcpy(t79, t74, 5U);
    t80 = (t0 + 8141);
    t82 = (12 - 0);
    t83 = (t82 * 1);
    t84 = (5U * t83);
    t85 = (t7 + t84);
    memcpy(t85, t80, 5U);
    t86 = (t0 + 8146);
    t88 = (13 - 0);
    t89 = (t88 * 1);
    t90 = (5U * t89);
    t91 = (t7 + t90);
    memcpy(t91, t86, 5U);
    t92 = (t0 + 8151);
    t94 = (14 - 0);
    t95 = (t94 * 1);
    t96 = (5U * t95);
    t97 = (t7 + t96);
    memcpy(t97, t92, 5U);
    t98 = (t0 + 8156);
    t100 = (15 - 0);
    t101 = (t100 * 1);
    t102 = (5U * t101);
    t103 = (t7 + t102);
    memcpy(t103, t98, 5U);
    t104 = (t0 + 8161);
    t106 = (16 - 0);
    t107 = (t106 * 1);
    t108 = (5U * t107);
    t109 = (t7 + t108);
    memcpy(t109, t104, 5U);
    t110 = (t0 + 8166);
    t112 = (17 - 0);
    t113 = (t112 * 1);
    t114 = (5U * t113);
    t115 = (t7 + t114);
    memcpy(t115, t110, 5U);
    t116 = (t0 + 8171);
    t118 = (18 - 0);
    t119 = (t118 * 1);
    t120 = (5U * t119);
    t121 = (t7 + t120);
    memcpy(t121, t116, 5U);
    t122 = (t0 + 8176);
    t124 = (19 - 0);
    t125 = (t124 * 1);
    t126 = (5U * t125);
    t127 = (t7 + t126);
    memcpy(t127, t122, 5U);
    t128 = (t0 + 8181);
    t130 = (20 - 0);
    t131 = (t130 * 1);
    t132 = (5U * t131);
    t133 = (t7 + t132);
    memcpy(t133, t128, 5U);
    t134 = (t0 + 8186);
    t136 = (21 - 0);
    t137 = (t136 * 1);
    t138 = (5U * t137);
    t139 = (t7 + t138);
    memcpy(t139, t134, 5U);
    t140 = (t0 + 8191);
    t142 = (22 - 0);
    t143 = (t142 * 1);
    t144 = (5U * t143);
    t145 = (t7 + t144);
    memcpy(t145, t140, 5U);
    t146 = (t0 + 8196);
    t148 = (23 - 0);
    t149 = (t148 * 1);
    t150 = (5U * t149);
    t151 = (t7 + t150);
    memcpy(t151, t146, 5U);
    t152 = (t0 + 8201);
    t154 = (24 - 0);
    t155 = (t154 * 1);
    t156 = (5U * t155);
    t157 = (t7 + t156);
    memcpy(t157, t152, 5U);
    t158 = (t0 + 8206);
    t160 = (25 - 0);
    t161 = (t160 * 1);
    t162 = (5U * t161);
    t163 = (t7 + t162);
    memcpy(t163, t158, 5U);
    t164 = (t0 + 8211);
    t166 = (26 - 0);
    t167 = (t166 * 1);
    t168 = (5U * t167);
    t169 = (t7 + t168);
    memcpy(t169, t164, 5U);
    t170 = (t0 + 8216);
    t172 = (27 - 0);
    t173 = (t172 * 1);
    t174 = (5U * t173);
    t175 = (t7 + t174);
    memcpy(t175, t170, 5U);
    t176 = (t0 + 8221);
    t178 = (28 - 0);
    t179 = (t178 * 1);
    t180 = (5U * t179);
    t181 = (t7 + t180);
    memcpy(t181, t176, 5U);
    t182 = (t0 + 8226);
    t184 = (29 - 0);
    t185 = (t184 * 1);
    t186 = (5U * t185);
    t187 = (t7 + t186);
    memcpy(t187, t182, 5U);
    t188 = (t0 + 8231);
    t190 = (30 - 0);
    t191 = (t190 * 1);
    t192 = (5U * t191);
    t193 = (t7 + t192);
    memcpy(t193, t188, 5U);
    t194 = (t0 + 8236);
    t196 = (31 - 0);
    t197 = (t196 * 1);
    t198 = (5U * t197);
    t199 = (t7 + t198);
    memcpy(t199, t194, 5U);
    t200 = (t0 + 4584);
    t201 = (t200 + 56U);
    t202 = *((char **)t201);
    t203 = (t202 + 56U);
    t204 = *((char **)t203);
    memcpy(t204, t3, 160U);
    xsi_driver_first_trans_fast(t200);
    goto LAB6;

LAB8:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 2152U);
    t4 = *((char **)t1);
    t1 = (t0 + 1512U);
    t7 = *((char **)t1);
    t10 = *((int *)t7);
    t16 = (t10 - 0);
    t11 = (t16 * 1);
    xsi_vhdl_check_range_of_index(0, 31, 1, t10);
    t12 = (5U * t11);
    t17 = (0 + t12);
    t1 = (t4 + t17);
    t8 = (t0 + 4648);
    t9 = (t8 + 56U);
    t13 = *((char **)t9);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t1, 5U);
    xsi_driver_first_trans_fast(t8);
    goto LAB6;

}

static void work_a_4024041728_0412081955_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(80, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t1 = (t0 + 4712);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 5U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 4440);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_4024041728_0412081955_init()
{
	static char *pe[] = {(void *)work_a_4024041728_0412081955_p_0,(void *)work_a_4024041728_0412081955_p_1,(void *)work_a_4024041728_0412081955_p_2};
	xsi_register_didat("work_a_4024041728_0412081955", "isim/UC_TEST_isim_beh.exe.sim/work/a_4024041728_0412081955.didat");
	xsi_register_executes(pe);
}
